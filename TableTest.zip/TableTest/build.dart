import 'package:polymer/builder.dart';
        
main(args) {
  build(entryPoints: ['web/tabletest.html'],
        options: parseOptions(args));
}
