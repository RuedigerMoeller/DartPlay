// Copyright (c) 2013, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

/**
 * Code transform for @observable. This library will be removed soon, it simply
 * reexports `observe.transformer`.
 */
// TODO(sigmund): deprecate and delete.
library observe.transform;

export 'transformer.dart';
